from flask import Flask, request
import json

app = Flask(__name__)


@app.get('/') #annotation
def home():
    return "Hello Python"


@app.get('/test')
def test():
    return "This is a test page"




################################################################## ########################## API Products #########################  ####################################### JSON #################
######################################################




catalog = []

@app.get('/api/products')
def get_products():
    # TODO: read products from DB and return them
    return json.dumps(catalog) 



@app.post('/api/products')
def save_product():
    product = request.get_json()
    catalog.append(product)

    return json.dumps(product)

products = [
    {
        'title': 'Product 1',
        'category': 'Category 1',
        'price': 10.99
    },
    {
        'title': 'Product 2',
        'category': 'Category 2',
        'price': 19.99
    },
]

@app.get('/api/products/count')
def get_list():
    count = len(catalog)
    return json.dumps(count)





# SJC=124388
# Create an endpoint that return the number of products in the catalog
# the endpoint should respond to a get request on /api/products/count
# google - python count elements on a list







# start the server manually
app.run(debug=True)